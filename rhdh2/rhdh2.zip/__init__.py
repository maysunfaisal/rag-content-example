"""Utility script to convert OCP docs from adoc to plain text."""
