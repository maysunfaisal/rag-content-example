"""hello world"""

def hello():
  print("Hello world")
